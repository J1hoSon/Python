import pygame
import sys
import random
import os

# 공유할때 오류 안나게
base_dir = os.path.dirname(__file__)
resource_dir = base_dir

os.chdir(resource_dir)

pygame.init()

# 화면 설정
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 800
TILE_SIZE = 800 // 12  # 가로12, 세로10 임미다
GRID_WIDTH = 12
GRID_HEIGHT = 10

# 색
WHITE = (255, 255, 255)
GOLDEN = (228, 156, 84)
PINK = (232, 129, 148)
MOSS_GREEN = (34, 70, 34)
BLUE = (100, 100, 255)
RED = (255, 100, 100)
LEFT_RIGHT_COLOR = (210, 175, 99)
BOTTOM_COLOR = (213, 188, 134)

# 화면 설정2
screen = pygame.display.set_mode((SCREEN_WIDTH + 400, SCREEN_HEIGHT))
pygame.display.set_caption("Hot Speed")

# 사진들
monkey_img = pygame.image.load("blue_monkey.png")
monkey_img = pygame.transform.scale(monkey_img, (TILE_SIZE, TILE_SIZE))

monkey2_img = pygame.image.load("red_monkey.png")
monkey2_img = pygame.transform.scale(monkey2_img, (TILE_SIZE, TILE_SIZE))

wall_img = pygame.image.load("wall1.png")
wall_img = pygame.transform.scale(wall_img, (TILE_SIZE, TILE_SIZE))

wallice_img = pygame.image.load("wallice2.png")
wallice_img = pygame.transform.scale(wallice_img, (TILE_SIZE, TILE_SIZE))

hot_img = pygame.image.load("hot.png")
hot_img = pygame.transform.scale(hot_img, (TILE_SIZE, TILE_SIZE))

ice_img = pygame.image.load("ice.png")
ice_img = pygame.transform.scale(ice_img, (TILE_SIZE, TILE_SIZE))

sik2_img = pygame.image.load("sik.png")
sik2_img = pygame.transform.scale(sik2_img, (TILE_SIZE, TILE_SIZE))

egg2_img = pygame.image.load("egg.png")
egg2_img = pygame.transform.scale(egg2_img, (TILE_SIZE, TILE_SIZE))

ham2_img = pygame.image.load("ham2.png")
ham2_img = pygame.transform.scale(ham2_img, (TILE_SIZE, TILE_SIZE))

# 말풍선
sik_icon = pygame.image.load("sik.png")
sik_icon = pygame.transform.scale(sik_icon, (20, 20))

egg_icon = pygame.image.load("egg.png")
egg_icon = pygame.transform.scale(egg_icon, (20, 20))

# 메인화면
main_screen_img = pygame.image.load("Start.png")
main_screen_img = pygame.transform.scale(main_screen_img, (1200, 800))

# 스타또 버튼
start_button_img = pygame.image.load("Start_Button.png")

# 폰트
font = pygame.font.SysFont(None, 30)
small_font = pygame.font.SysFont(None, 20)

# 메인
def main_screen():
    while True:
        screen.blit(main_screen_img, (0, 0))

        # 스타또 버튼 그리기
        start_button_rect = start_button_img.get_rect(topleft=(850, 600))
        screen.blit(start_button_img, start_button_rect)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if start_button_rect.collidepoint(event.pos):
                    return

main_screen()

# 맵 1,2,3라운드
maps = [
    [
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
    ],
    [
        [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0],
        [0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0],
        [1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0],
        [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1],
        [0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0],
        [0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0],
        [0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0],
        [0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0],
    ],
    [
        [0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
        [0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0],
        [0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0],
        [0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0],
        [0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0],
        [0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0],
        [0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0],
        [0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0],
        [0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0],
    ],
]

current_level = 0
map_data = maps[current_level]

# 벽 위치 설정
wall_positions = [(col, row) for row in range(len(map_data)) for col in range(len(map_data[row])) if map_data[row][col] == 1]

cursor1_x, cursor1_y = GRID_WIDTH - 1, 0  # P1
(cursor2_x, cursor2_y) = 0, 0  # P2
sik_collected_p1 = 0
egg_collected_p1 = 0
sik_collected_p2 = 0
egg_collected_p2 = 0

# 이긴 횟수
player1_wins = 0
player2_wins = 0
last_winner = None


# 랜덤 위치 설정
remaining_positions = [(x, y) for x in range(GRID_WIDTH) for y in range(GRID_HEIGHT) if (x, y) not in wall_positions and (x, y) != (cursor1_x, cursor1_y) and (x, y) != (cursor2_x, cursor2_y)]
hot_positions = random.sample(remaining_positions, 2)
ice_positions = random.sample([pos for pos in remaining_positions if pos not in hot_positions], 2)
remaining_positions = [pos for pos in remaining_positions if pos not in hot_positions and pos not in ice_positions]
wallice_positions = random.sample(remaining_positions, 20)

# ham2(햄스터 사진) 위치 / *맨 위 0열 위치 x, 포탈이랑 중복 x* / 햄스터 계란, 식혜 요구 1~2개
ham2_position_candidates = [pos for pos in remaining_positions if pos[1] > 0 and pos not in hot_positions and pos not in ice_positions]
ham2_position = random.choice(ham2_position_candidates)
ham2_sik_required = random.randint(1, 2)
ham2_egg_required = random.randint(1, 2)

# 얼음벽안에 식혜랑 계란 배치
item_positions = {}
sik_positions = random.sample(wallice_positions, 5)
egg_positions = random.sample([pos for pos in wallice_positions if pos not in sik_positions], 5)
for pos in sik_positions:
    item_positions[pos] = "sik"
for pos in egg_positions:
    item_positions[pos] = "egg"

# 게임 메인 코드
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            # P1 조작키
            next_x1, next_y1 = cursor1_x, cursor1_y
            if event.key == pygame.K_UP and cursor1_y > 0:
                next_y1 -= 1
            elif event.key == pygame.K_DOWN and cursor1_y < GRID_HEIGHT - 1:
                next_y1 += 1
            elif event.key == pygame.K_LEFT and cursor1_x > 0:
                next_x1 -= 1
            elif event.key == pygame.K_RIGHT and cursor1_x < GRID_WIDTH - 1:
                next_x1 += 1

            # 벽 있는 좌표 이동 x
            if (next_x1, next_y1) not in wall_positions:
                cursor1_x, cursor1_y = next_x1, next_y1

            # P2 조작키
            next_x2, next_y2 = cursor2_x, cursor2_y
            if event.key == pygame.K_w and cursor2_y > 0:
                next_y2 -= 1
            elif event.key == pygame.K_s and cursor2_y < GRID_HEIGHT - 1:
                next_y2 += 1
            elif event.key == pygame.K_a and cursor2_x > 0:
                next_x2 -= 1
            elif event.key == pygame.K_d and cursor2_x < GRID_WIDTH - 1:
                next_x2 += 1

            # 벽 있는 좌표 이동 x
            if (next_x2, next_y2) not in wall_positions:
                cursor2_x, cursor2_y = next_x2, next_y2

            # P1,P2 얼음벽 충돌 시 얼음벽 제거
            if (cursor1_x, cursor1_y) in wallice_positions:
                wallice_positions.remove((cursor1_x, cursor1_y))
            if (cursor2_x, cursor2_y) in wallice_positions:
                wallice_positions.remove((cursor2_x, cursor2_y))

            # Enter 상호작용 (P1)
            if event.key == pygame.K_RETURN:
                # 아이템 먹기
                if (cursor1_x, cursor1_y) in item_positions:
                    if item_positions[(cursor1_x, cursor1_y)] == "sik" and sik_collected_p1 < 2:
                        sik_collected_p1 += 1
                        del item_positions[(cursor1_x, cursor1_y)]
                    elif item_positions[(cursor1_x, cursor1_y)] == "egg" and egg_collected_p1 < 2:
                        egg_collected_p1 += 1
                        del item_positions[(cursor1_x, cursor1_y)]

                # 햄스터 상호작용
                if (cursor1_x, cursor1_y) == ham2_position:
                    if sik_collected_p1 >= ham2_sik_required and egg_collected_p1 >= ham2_egg_required:
                        last_winner = "player1"
                        sik_collected_p1 -= ham2_sik_required
                        egg_collected_p1 -= ham2_egg_required
                        ham2_position = None #햄스터 제거

                # hot, ice 포탈 (P1)
                if (cursor1_x, cursor1_y) in hot_positions:
                    for pos in hot_positions:
                        if (cursor1_x, cursor1_y) != pos:
                            cursor1_x, cursor1_y = pos
                            break

                elif (cursor1_x, cursor1_y) in ice_positions:
                    for pos in ice_positions:
                        if (cursor1_x, cursor1_y) != pos:
                            cursor1_x, cursor1_y = pos
                            break

                # hot이나 ice 포탈이 벽과 같은 좌표에 있는 경우 벽 제거 (P1)
                if (cursor1_x, cursor1_y) in hot_positions or (cursor1_x, cursor1_y) in ice_positions:
                    if (cursor1_x, cursor1_y) in wall_positions:
                        wall_positions.remove((cursor1_x, cursor1_y))

            # Space 상호작용 (P2)
            if event.key == pygame.K_SPACE:
                # 아이템 먹기
                if (cursor2_x, cursor2_y) in item_positions:
                    if item_positions[(cursor2_x, cursor2_y)] == "sik" and sik_collected_p2 < 2:
                        sik_collected_p2 += 1
                        del item_positions[(cursor2_x, cursor2_y)]
                    elif item_positions[(cursor2_x, cursor2_y)] == "egg" and egg_collected_p2 < 2:
                        egg_collected_p2 += 1
                        del item_positions[(cursor2_x, cursor2_y)]

                # 햄스터 상호작용
                if (cursor2_x, cursor2_y) == ham2_position:
                    if sik_collected_p2 >= ham2_sik_required and egg_collected_p2 >= ham2_egg_required:
                        last_winner = "player2"
                        sik_collected_p2 -= ham2_sik_required
                        egg_collected_p2 -= ham2_egg_required
                        ham2_position = None  #햄스터 제거

                # hot, ice 포탈 (P2)
                if (cursor2_x, cursor2_y) in hot_positions:
                    for pos in hot_positions:
                        if (cursor2_x, cursor2_y) != pos:
                            cursor2_x, cursor2_y = pos
                            break

                elif (cursor2_x, cursor2_y) in ice_positions:
                    for pos in ice_positions:
                        if (cursor2_x, cursor2_y) != pos:
                            cursor2_x, cursor2_y = pos
                            break

                # hot이나 ice 포탈이 벽과 같은 좌표에 있는 경우 벽 제거 (P2)
                if (cursor2_x, cursor2_y) in hot_positions or (cursor2_x, cursor2_y) in ice_positions:
                    if (cursor2_x, cursor2_y) in wall_positions:
                        wall_positions.remove((cursor2_x, cursor2_y))

    # 화면
    screen.fill(LEFT_RIGHT_COLOR)
    pygame.draw.rect(screen, LEFT_RIGHT_COLOR, (0, 0, 200, SCREEN_HEIGHT))  # 왼쪽 여백
    pygame.draw.rect(screen, LEFT_RIGHT_COLOR, (SCREEN_WIDTH + 200, 0, 200, SCREEN_HEIGHT))  # 오른쪽 여백
    pygame.draw.rect(screen, BOTTOM_COLOR, (0, SCREEN_HEIGHT - 140, SCREEN_WIDTH + 400, 140))  # 아래 여백

    for row in range(GRID_HEIGHT):
        for col in range(GRID_WIDTH):
            color = GOLDEN if (row + col) % 2 == 0 else PINK
            pygame.draw.rect(screen, color, (col * TILE_SIZE + 200, row * TILE_SIZE, TILE_SIZE, TILE_SIZE))

    # 벽 이미지
    for x, y in wall_positions:
        screen.blit(wall_img, (x * TILE_SIZE + 200, y * TILE_SIZE))

    # 얼음벽, 아이템 이미지
    for x, y in wallice_positions:
        screen.blit(wallice_img, (x * TILE_SIZE + 200, y * TILE_SIZE))
    for (x, y), item in item_positions.items():
        if (x, y) not in wallice_positions:  # wallice가 제거된 경우 아이템 보이기
            if item == "sik":
                screen.blit(sik2_img, (x * TILE_SIZE + 200, y * TILE_SIZE))
            elif item == "egg":
                screen.blit(egg2_img, (x * TILE_SIZE + 200, y * TILE_SIZE))

    # hot, ice 포탈 이미지
    for x, y in hot_positions:
        screen.blit(hot_img, (x * TILE_SIZE + 200, y * TILE_SIZE))
    for x, y in ice_positions:
        screen.blit(ice_img, (x * TILE_SIZE + 200, y * TILE_SIZE))

    # 햄스터, 말풍선 이미지
    if ham2_position:
        x, y = ham2_position
        screen.blit(ham2_img, (x * TILE_SIZE + 200, y * TILE_SIZE))
        # 말풍선
        speech_rect = pygame.Rect(x * TILE_SIZE + 200, y * TILE_SIZE - 40, TILE_SIZE, 40)
        pygame.draw.rect(screen, WHITE, speech_rect)
        pygame.draw.rect(screen, (0, 0, 0), speech_rect, 2)  # 검은 테두리
        screen.blit(sik_icon, (x * TILE_SIZE + 205, y * TILE_SIZE - 38))
        sik_text = small_font.render(f"x {ham2_sik_required}", True, (0, 0, 0))
        screen.blit(sik_text, (x * TILE_SIZE + 225, y * TILE_SIZE - 38))
        screen.blit(egg_icon, (x * TILE_SIZE + 205, y * TILE_SIZE - 18))
        egg_text = small_font.render(f"x {ham2_egg_required}", True, (0, 0, 0))
        screen.blit(egg_text, (x * TILE_SIZE + 225, y * TILE_SIZE - 18))

    # 원숭이 두마리 이미지
    screen.blit(monkey_img, (cursor1_x * TILE_SIZE + 200, cursor1_y * TILE_SIZE))
    screen.blit(monkey2_img, (cursor2_x * TILE_SIZE + 200, cursor2_y * TILE_SIZE))

    # 현재 이이템 개수 표시
    text_p1 = font.render(f"Player 2 - Drink: {sik_collected_p1}", True, BLUE)
    screen.blit(text_p1, (10, SCREEN_HEIGHT - 60))
    text_p1_egg = font.render(f"Egg: {egg_collected_p1}", True, BLUE)
    screen.blit(text_p1_egg, (10, SCREEN_HEIGHT - 40))

    text_p2 = font.render(f"Player 1 - Drink: {sik_collected_p2}", True, RED)
    screen.blit(text_p2, (10, SCREEN_HEIGHT - 100))
    text_p2_egg = font.render(f"Egg: {egg_collected_p2}", True, RED)
    screen.blit(text_p2_egg, (10, SCREEN_HEIGHT - 80))

    # 햄스터 제거 시 다음 라운드
    if ham2_position is None:  # 햄스터가 제거된 경우
        if last_winner == "player1":
            player1_wins += 1
        elif last_winner == "player2":
            player2_wins += 1

        # 게임 승리 조건
        if player1_wins == 2 or player2_wins == 2:
            # 승리시 승리 이미지!
            if player1_wins == 2:
                winner_image = pygame.image.load("blue_final.png")
            else:
                winner_image = pygame.image.load("red_final.png")

            # 승리 이미지 크기 맞추기
            winner_image = pygame.transform.scale(winner_image, (SCREEN_WIDTH + 400, SCREEN_HEIGHT))
            screen.blit(winner_image, (0, 0))

            pygame.display.flip()
            pygame.time.wait(5000)
            running = False

        else:
            current_level += 1  # 다음 라운드 전환
            if current_level < len(maps):  # 더 많은 라운드가 있으면
                map_data = maps[current_level]

                # 플레이어 위치 초기화
                cursor1_x, cursor1_y = GRID_WIDTH - 1, 0  # P1 시작위치
                cursor2_x, cursor2_y = 0, 0  # P2 시작위치

                # 벽 위치
                wall_positions = [(col, row) for row in range(len(map_data)) for col in range(len(map_data[row])) if map_data[row][col] == 1]

                # 아이템이랑 햄스터 위치
                remaining_positions = [(x, y) for x in range(GRID_WIDTH) for y in range(GRID_HEIGHT) if (x, y) not in wall_positions and (x, y) != (cursor1_x, cursor1_y) and (x, y) != (cursor2_x, cursor2_y)]
                hot_positions = random.sample(remaining_positions, 2)
                ice_positions = random.sample([pos for pos in remaining_positions if pos not in hot_positions], 2)
                remaining_positions = [pos for pos in remaining_positions if pos not in hot_positions and pos not in ice_positions]
                wallice_positions = random.sample(remaining_positions, 20)
                ham2_position_candidates = [pos for pos in remaining_positions if pos[1] > 0 and pos not in hot_positions and pos not in ice_positions]
                ham2_position = random.choice(ham2_position_candidates)
                ham2_sik_required = random.randint(1, 2)  # 식혜 요구 1~2개
                ham2_egg_required = random.randint(1, 2)  # 계란 요구 1~2개
                item_positions = {}
                sik_positions = random.sample(wallice_positions, 5)
                egg_positions = random.sample([pos for pos in wallice_positions if pos not in sik_positions], 5)
                for pos in sik_positions:
                    item_positions[pos] = "sik"
                for pos in egg_positions:
                    item_positions[pos] = "egg"
            else:
                # 게임 끝
                running = False

    pygame.display.flip()

# 프로그램 종료
pygame.quit()
sys.exit()
